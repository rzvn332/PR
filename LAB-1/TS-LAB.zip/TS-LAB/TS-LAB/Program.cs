﻿using TI206_PR;

ServerSocket server = new ServerSocket("172.20.10.5", 5050);

server.BindAndListen(10);
server.AcceptAndReceive();
